import requests
key = "add api key here"
api_address1 = "https://newsapi.org/v2/top-headlines?country=us&apiKey="+ key


json_data1 = requests.get(api_address1).json()
ar =[]

def news():
    for i in range(3):
        ar.append("Number" + str(i+1) + ", " + json_data1["articles"][i]["title"]+".")
        return ar








